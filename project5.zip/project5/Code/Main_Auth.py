import serial
import time
import random
import os

SERIAL_PORT = 'COM8' 
BAUD_RATE = 9600

def rotate_left_8bit(val, n):
    return ((val << n) | (val >> (8 - n))) & 0xFF

def run_auth_system():
    try:
        if os.path.exists("secret.txt"):
            with open("secret.txt", "r") as f:
                priv_key = int(f.read().strip())
        else:
            priv_key = 165 

        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
        time.sleep(2) 

        correct_buttons = 10 
        seed = random.randint(1, 254)
        
       
        step1 = seed ^ priv_key
        rotated = rotate_left_8bit(step1, 3)
        expected_otp = rotated ^ correct_buttons
        ser.write(bytes([seed]))
        
        print("Press the 4-button sequence on Arduino...")
        
        while True:
            if ser.in_waiting > 0:
                arduino_otp = ord(ser.read(1))
                print(f"Arduino: {arduino_otp} | Expected: {expected_otp}")
                
                if arduino_otp == expected_otp:
                    print(">>> ACCESS GRANTED <<<")
                else:
                    print(">>> ACCESS DENIED <<<")
                break
        
        ser.close()

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    run_auth_system()