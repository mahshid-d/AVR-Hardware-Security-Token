import serial
import time
import os

def run_config():

    PORT = 'COM8' 
    BAUD = 9600

    try:
       
        user_input = input("[?] Enter NEW Private Key (0-255): ")
        new_key = int(user_input)

        if not (0 <= new_key <= 255):
            print("[!] Error: Number must be between 0 and 255.")
            return

        print("When both LEDs are ON, press ENTER here.")
        input("\n>>> Press ENTER to start sending...")

        print(f"Opening {PORT} and waiting for Arduino to boot...")
        ser = serial.Serial(PORT, BAUD, timeout=1)
        time.sleep(3) 
        
        print(f"Sending Key: {new_key}")
        ser.write(bytes([new_key]))

        with open("secret.txt", "w") as f:
            f.write(str(new_key))

        print("\n[SUCCESS] Key sent!")
        print("Now look at Arduino: RED should turn OFF and GREEN should BLINK.")
        print("If that happened, you can release the button.")
        
        ser.close()

    except ValueError:
        print("[!] Error: Please enter a valid number.")
    except Exception as e:
        print(f"[!] Error: {e}")

if __name__ == "__main__":
    run_config()